﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace Inquerito
{
    public class DBConnectMySQL
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string username;
        private string password;
        private string port;
        
        public DBConnectMySQL()
        {
            Initialize();
        }

        private void Initialize()
        {
            string connectionString;
            // add server------------------------------------------------------------------------------------------------------------------
            //-----------------------------------------------------------------------------------------------------------------------------
            server = "";
            database = "Prog22094";
            username = "User22094";
            password = "User22094root";
            port = "3306";

            connectionString = "Server=" + server + ";Port=" + port + ";Database=" + database + ";Uid=" + username + ";Pwd=" + password + ";";

            connection = new MySqlConnection(connectionString);
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public bool Insert(string nome, string distrito, string comida, string clube)
        {
            bool flag = true;

            try
            {
                string query = "insert into dados (nome, distrito, comida, clube) values ('" +
                    nome + "','" + distrito + "','" + comida + "','" + clube + "');";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                Debug.WriteLine(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }
            return flag;
        }
    }

    
}